==========
redpackets
==========

RedPackets Split & Return split_list if succeed & Raise Exception if failed

Installation
============

::

    pip install redpackets


Usage
=====

::

    import redpackets

    redpackets.split(total, num, min=0.01)
