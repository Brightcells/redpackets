from redpackets.main import (
    split,
)
